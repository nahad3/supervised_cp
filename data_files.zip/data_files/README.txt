This folder contains datafiles for the SinkDiVML change point detection method.


All data files are .mat files.

All data files have 2 structs:

Y: Input sequence over which changes are to be detected
L: Labels for change points


For HASC-2016 dataset, the 89 files were too large for the submission portal.
These can be downloaded from the link shared in the supplementary section of the paper.